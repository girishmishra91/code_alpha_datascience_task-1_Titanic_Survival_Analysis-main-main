# code_alpha_datascience_task-1_Titanic_Survival_Analysis-main
Make a system which tells whether the person will  be save from sinking. What factors were most likely  lead to success-socio-economic status, age, gender  and more.
